package com.example.controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.example.model.PhoneBook;
import com.example.service.PhoneBookService;


@Controller
@RequestMapping("phonebook")
public class PhoneBookController {
	@Autowired
	private PhoneBookService phoneBookService;
	@GetMapping("/list")
	public String getAllPhoneBook(Model model) {
		List<PhoneBook> phoneBookList=phoneBookService.getAllPhoneBook();
		model.addAttribute("phoneBookList",phoneBookList);
		return "phonebook/phonebook_list"; 
	}
//	them
	@GetMapping("/add")
	public String addPhoneBook(Model model) {
		PhoneBook phoneBook =new PhoneBook();
		model.addAttribute("phoneBook",phoneBook);
		return "phonebook/phonebook_add";
		
	}
//	xoa
	@GetMapping("/delete/{id}")
	public String deletePhoneBook( @PathVariable("id")int id) {
		phoneBookService.deletePhoneBook(id);
		return "redirect:/phonebook/list";
	}
//sua
	@GetMapping("edit/{id}")
	public String editPhoneBook(@PathVariable("id") int id, Model model ) {
		PhoneBook phoneBook = phoneBookService.findPhoneBookById(id);
		model.addAttribute("phoneBook",phoneBook);
		return "phonebook/phonebook_update";
	}
	@PostMapping("/update")
	public String updatePhoneBook(@ModelAttribute("phoneBook") PhoneBook phoneBook) {
		phoneBookService.updatePhoneBook(phoneBook);
		return "redirect:/phonebook/list";
	}
//	luu lai
	@PostMapping("/save")
	public String savePhoneBook(@ModelAttribute("phoneBook")PhoneBook phoneBook) {
		phoneBookService.addPhoneBook(phoneBook);
		return "redirect:/phonebook/list";
		
	}
//	@PostMapping("/search/{lastName}")
//	public String searchPhoneBook(@PathVariable("last_name") int last_name, Model model ) {
//		PhoneBook phoneBook = phoneBookService.findPhoneBookById(last_name);
//		model.addAttribute("phoneBook",phoneBook);
//		return "redirect:/phonebook/list";
//	}

	@GetMapping("/search/{lastName}")
	public String searchPhoneBook(@PathVariable("lastName") String lastName, Model model) {
		List<PhoneBook> phoneBook = phoneBookService.searchPhoneBookByName(lastName);
		model.addAttribute("phoneBook", phoneBook);
		return "redirect:/phonebook/phonebook_list";
	}
	@PostMapping("/search")
	public String search(@ModelAttribute("phoneBook") PhoneBook phoneBook,
			@RequestParam("lastName") String lastName, Model model) {
	    List<PhoneBook> phoneBookList = phoneBookService.searchPhoneBookByName(lastName);
	    model.addAttribute("phoneBookList", phoneBookList);
	    return "redirect:/phonebook/phonebook_list";
	}

}
