package com.example.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.model.PhoneBook;
import com.example.respository.PhoneBookMapper;

@Service
public class PhoneBookServiceImpl implements PhoneBookService{
	@Autowired
	private PhoneBookMapper mapper;
	@Override
	public List<PhoneBook> getAllPhoneBook() {
		return mapper.getAllPhoneBook();
	}
	public void addPhoneBook(PhoneBook phoneBook) {
		// TODO Auto-generated method stub
		mapper.addPhoneBook(phoneBook);		
	}
	@Override
	public void deletePhoneBook(int id) {
		mapper.deletePhoneBook(id);
	}
	@Override
	public PhoneBook findPhoneBookById(int id) {
		PhoneBook phoneBook = mapper.findPhoneBookById(id);
		return phoneBook;
	}
	@Override
	public void updatePhoneBook(PhoneBook phoneBook) {
		mapper.updatePhoneBook(phoneBook);
		
	}
	@Override
	public void searchPhoneBook(String lastName) {
		mapper.getPhoneBookByCriceria(lastName);
	}
	@Override
	public List<PhoneBook> searchPhoneBookByName(String lastName) {
		return null;
	}
	@Override
	public List<PhoneBook> findByName(String lastName) {
		return null;
	}
	


}
