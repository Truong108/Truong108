 /*****   ITEM Data   ************************************************************/

INSERT INTO ITEM (description, purchase_date, store, city, quantity, local_currency_amount, exchange_rate)
    VALUES
    	('QE dining set','2011-04-07', 'Eastern Treasures', 'Manila', 2, 403405, 0.01774),
    	('Willow serving dishes', '2011-07-15', 'Jade Antiques', 'Singapore', 75, 102, 0.5903),
    	('Large Bureau', '2011-07-17', 'Eastern Sales', 'Singapore', 8, 2000, 0.5903),
    	('Brass lamps', '2011-07-20', 'Jade Antiques', 'Singapore', 40, 50, 0.5903);

/*****   SHIPMENT Data   ***********************************************************/

INSERT INTO shipment(shipper_name, shipper_invoice_number, departure_date, arrival_date, insured_value)
	VALUES
		('ABC Trans-Oceanic', 2008651, '2010-12-10', '2011-03-15', 15000.00),
		('ABC Trans-Oceanic', 2009012, '2011-01-10', '2011-03-20', 12000.00),
		('Worldwide', 49100300, '2011-05-05', '2011-06-17', 20000.00),
		('International', 399400, '2011-06-02', '2011-07-17', 17500.00),
		('Worldwide', 84899440, '2011-07-10', '2011-07-28', 25000.00),
		('International', 488955, '2011-08-05', '2011-10-11', 18000.00);

/*****   SHIPMENT Item   ***********************************************************/

INSERT INTO SHIPMENT_ITEM(shipment_id, shipment_item_id, item_id, cost) 
	VALUES
	(3, 1, 1, 15000),
	(4, 1, 4, 1200),
	(4, 2, 3, 9500),
	(4, 3, 2, 4500);


/********************************************************************************/

