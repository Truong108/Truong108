package com.example.model;

import java.util.Date;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class Item {
	private Integer itemId;
	private String description;
	private Date purchaseDate;
	private String store;
	private String city;
	private Integer quantity;
	private Double localCurrencyAmount;
	private Double exchangeRate;
}
