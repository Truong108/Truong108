package com.example.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.example.model.Author;
import com.example.model.Book;
import com.example.service.AuthorService;
import com.example.service.BookService;

@Controller
@RequestMapping("/book")
public class BookController {
	
	@Autowired
	private AuthorService authorService;
	@Autowired
	private BookService bookService;
	
	@GetMapping("/list")
	String getAllBook(@RequestParam(value = "authorId", required = false) Integer authorId, Model model) {
		List<Author> authorList = authorService.getAllAuthor();
		List<Book> bookList = bookService.getBooks(authorId);
		model.addAttribute("authorList",authorList);
		model.addAttribute("bookList",bookList);
		model.addAttribute("authorId",authorId);
		return "book/book_list";
	}
	
	

	@PostMapping("/list")
	String postAllBook(@RequestParam(value = "authorId", required = false) Integer authorId, Model model) {
		List<Author> authorList = authorService.getAllAuthor();
		List<Book> bookList = bookService.getBooks(authorId);
		model.addAttribute("authorList",authorList);
		model.addAttribute("bookList",bookList);
		model.addAttribute("authorId",authorId);
		return "book/book_list";
	}
}
