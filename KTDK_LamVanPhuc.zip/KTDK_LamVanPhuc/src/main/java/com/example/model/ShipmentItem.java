package com.example.model;

import lombok.Data;

@Data
public class ShipmentItem {
	private Integer shipmentId;
	private Integer shipmentItemId;
	private Integer itemId;
	private Double cost;
	private Item item;
	private Shipment shipment;
}
