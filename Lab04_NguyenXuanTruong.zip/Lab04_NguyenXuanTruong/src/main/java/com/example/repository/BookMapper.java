package com.example.repository;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import com.example.model.Book;

@Mapper
public interface BookMapper {
	public List<Book> findMany(@Param("authorId") Integer authorId);
}
