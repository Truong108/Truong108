package com.example.model;

import lombok.Data;

@Data
public class Book {
	private Integer id;
	private String title;
	private String isbn;
	private Author author;
}
