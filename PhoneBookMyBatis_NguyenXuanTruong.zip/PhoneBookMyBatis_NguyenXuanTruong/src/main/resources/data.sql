insert into phone_book(first_name,last_name,phone_number)
values 
('Tu','Tran Khai','0326216612'),
('Hai','Nguyen Dinh','0733810982'),
('Tuan','Tran Nguyen Ngoc','0376281003'),
('Han','Vo Ngoc','0807035662'),
('Hong','Tong Thi Thuy','095532135');