package com.example.respository;

import java.util.List;

import com.example.model.PhoneBook;

public interface PhoneBookRepository {
	public List<PhoneBook> getAllPhoneBook();
	
	void addPhoneBook(PhoneBook phoneBook);

	public void deletePhoneBook(int id);

	public PhoneBook findPhoneBookById(int id);

	public void updatePhoneBook(PhoneBook phoneBook);
	
	public void searchPhoneBook(String lastName);






}
