CREATE TABLE IF NOT EXISTS author (
  id int not null auto_increment,
  age int,
  genre nvarchar(255),
  name nvarchar(255),
  primary key (id)
);

CREATE TABLE IF NOT EXISTS book(
	id int not null auto_increment,
	isbn varchar(255),
	title varchar(255),
	author_id int,
	primary key (id),
	foreign key (author_id) references author(id)
);

