package com.example.controller;

import java.util.ArrayList;
import java.util.List;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.example.form.GroupOrder;
import com.example.form.ItemForm;
import com.example.model.Item;
import com.example.model.Shipment;
import com.example.model.ShipmentItem;
import com.example.service.ItemService;
import com.example.service.ShipmentService;

import lombok.extern.slf4j.Slf4j;

@Controller
@RequestMapping("/item")
@Slf4j
public class ItemController {
	@Autowired
	ItemService itemService;
	@Autowired
	ShipmentService shipmentService;
	@Autowired
	ModelMapper mapper;

	@GetMapping("/add")
	public String getAdd(Model model) {
//		@ModelAttribute @Validated(GroupOrder.class) ItemForm form
		Item item = new Item();
		model.addAttribute("item", item);
		return "item/add";
	}

	@PostMapping("/add")
	public String postSignup(@ModelAttribute("item") Item item) {
//		, @ModelAttribute @Validated(GroupOrder.class) ItemForm form,
//		BindingResult bindingResult
//
//		if (bindingResult.hasErrors()) {
//
//			return getAdd(model, form);
//		}
		
//		Item item = mapper.map(form, Item.class);
//		itemService.addItem(item);
//		log.info(form.toString());
		// Redirect to login screen
		itemService.addItem(item);
		return "redirect:/item/list";
	}

	@GetMapping("/list")
	public String viewItem(@RequestParam(value = "selectId", required = false) Integer selectId, Model model) {
		List<Shipment> shipment = shipmentService.getAllShipment();
		List<ShipmentItem> item = itemService.getAllItem(selectId);
		model.addAttribute("itemList", item);
		model.addAttribute("shipmentList", shipment);
		model.addAttribute("selectId", selectId);
		return "shipment/shipment_list";
	}

	@PostMapping("/list")
	public String postItem(@RequestParam(value = "selectId", required = false) Integer selectId, Model model) {
		List<Shipment> shipment = shipmentService.getAllShipment();
		List<ShipmentItem> item = itemService.getAllItem(selectId);
		model.addAttribute("itemList", item);
		model.addAttribute("shipmentList", shipment);
		model.addAttribute("selectId", selectId);
		return "shipment/shipment_list";
	}

	@GetMapping("/delete/{id}")
	public String deleteOneItem(@PathVariable("id") Integer id) {
		itemService.deleteOneItem(id);
		return "redirect:/item/list";
	}
}
