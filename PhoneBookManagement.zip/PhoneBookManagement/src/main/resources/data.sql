insert into phone_book(first_name,last_name,phone_number)
values 
('Dat','Tran Quang','0923121242'),
('An','Nguyen Dinh','0939124223'),
('Ngoc','Tran Nguyen Nhu','0344972761'),
('Chau','Vo Ngoc','0972658827');