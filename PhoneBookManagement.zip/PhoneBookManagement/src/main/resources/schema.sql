create table phone_book(
id int auto_increment primary key,
first_name varchar(50),
last_name varchar(100),
phone_number varchar(20)
);