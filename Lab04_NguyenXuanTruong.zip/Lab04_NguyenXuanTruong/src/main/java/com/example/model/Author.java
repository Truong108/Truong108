package com.example.model;

import lombok.Data;

@Data
public class Author {
	private Integer id;
	private Integer age;
	private String genre;
	private String name;
}
