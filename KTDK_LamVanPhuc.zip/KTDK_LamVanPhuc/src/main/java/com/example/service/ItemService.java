package com.example.service;

import java.util.List;

import com.example.model.Item;
import com.example.model.ShipmentItem;

public interface ItemService {
	public void addItem(Item item);

	public List<ShipmentItem> getAllItem();

	public List<ShipmentItem> getAllItem(Integer selectId);
//	public List<Item> getAllItem();

	public void deleteOneItem(Integer id);

}
