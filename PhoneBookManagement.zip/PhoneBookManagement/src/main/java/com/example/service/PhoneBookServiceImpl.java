package com.example.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.model.PhoneBook;
import com.example.respository.PhoneBookRepository;

@Service
public class PhoneBookServiceImpl implements PhoneBookService{
	@Autowired
	private PhoneBookRepository phoneBookRepo;
	@Override
	public List<PhoneBook> getAllPhoneBook() {
		return phoneBookRepo.getAllPhoneBook();
	}
	public void addPhoneBook(PhoneBook phoneBook) {
		// TODO Auto-generated method stub
		phoneBookRepo.addPhoneBook(phoneBook);		
	}
	@Override
	public void deletePhoneBook(int id) {
		// TODO Auto-generated method stub
		phoneBookRepo.deletePhoneBook(id);
	}
	@Override
	public PhoneBook findPhoneBookById(int id) {
		PhoneBook phoneBook=phoneBookRepo.findPhoneBookById(id);
		return phoneBook;
	}
	@Override
	public void updatePhoneBook(PhoneBook phoneBook) {
		phoneBookRepo.updatePhoneBook(phoneBook);
		
	}


}
