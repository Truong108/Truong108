package com.example.form;

import lombok.Data;

@Data
public class UserListForm {
	private String userId;
	private String userName;
	

}
