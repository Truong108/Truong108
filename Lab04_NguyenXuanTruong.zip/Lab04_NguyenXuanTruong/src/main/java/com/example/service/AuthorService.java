package com.example.service;

import java.util.List;

import com.example.model.Author;

public interface AuthorService {
	public List<Author> getAllAuthor();
	public Author getOneAuthor(Integer id);
	public void deleteAuthor(Integer id);
	public void updateAuthor(Author author);
	public void createAuthor(Author author);
}
