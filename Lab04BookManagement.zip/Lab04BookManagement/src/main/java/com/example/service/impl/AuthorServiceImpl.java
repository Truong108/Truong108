package com.example.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.model.Author;
import com.example.repository.AuthorMapper;
import com.example.service.AuthorService;
@Service
public class AuthorServiceImpl implements AuthorService{
	@Autowired AuthorMapper mapper;
	@Override
	public List<Author> getAllAuthor() {
		
		return mapper.findMany();
	}
	@Override
	public void deleteAuthor(Integer id) {
		mapper.deleteOne(id);
	}
	@Override
	public Author getOneAuthor(Integer id) {
		
		return mapper.findOne(id);
	}
	@Override
	public void updateAuthor(Author author) {
		mapper.updateOne(author);
		
	}
	@Override
	public void createAuthor(Author author) {
		mapper.insertOne(author);
		
	}
	
}
