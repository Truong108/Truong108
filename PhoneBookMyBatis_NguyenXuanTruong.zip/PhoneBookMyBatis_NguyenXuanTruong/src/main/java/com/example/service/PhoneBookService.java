package com.example.service;

import java.util.List;

import com.example.model.PhoneBook;

public interface PhoneBookService {
	public List<PhoneBook> getAllPhoneBook();
	
	public List<PhoneBook> findByName(String lastName);

	public void addPhoneBook(PhoneBook phoneBook);

	public void deletePhoneBook(int id);

	public PhoneBook findPhoneBookById(int id);

	public void updatePhoneBook(PhoneBook phoneBook);

	public List<PhoneBook> searchPhoneBookByName(String lastName);

	public void searchPhoneBook(String lastName);

	

	
}
