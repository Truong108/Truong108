package com.example.hello;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class HelloService {
	@Autowired
	private  HelloRepository repository;
	
	public Employee getEmployee (String id) {
		Employee emp =new Employee();
		Map<String, Object> map =repository.findById(id);
		String idEmp=(String)map.get("id");
		String name=(String)map.get("name");
		int age=(int)map.get("age");
		
		emp.setId(idEmp);
		emp.setName(name);
		emp.setAge(age);

		return emp;
		
	}
	

}
