package com.example.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.model.Shipment;
import com.example.repository.DataMapper;
import com.example.service.ShipmentService;

@Service
public class ShipmentServiceImpl implements ShipmentService {
	@Autowired
	DataMapper mapper;

	@Override
	public List<Shipment> getAllShipment() {
		
		return mapper.findManyShipment();
	}


}
