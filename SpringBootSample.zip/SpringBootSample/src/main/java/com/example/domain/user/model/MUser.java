package com.example.domain.user.model;

import java.util.Date;
import java.util.List;

import org.springframework.data.annotation.Id;


import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;
import lombok.Data;


@Data
@Entity
@Table(name ="m_user")
public class MUser {
	@Id
	private String userId;
	@Column(name ="password")
	private String password;
	@Column(name ="user_name")
	private String userName;
	@Column(name ="birthday")
	private Date birthday;
	@Column(name ="age")
	private Integer age;
	@Column(name ="gender")
	private Integer gender;
	private Integer departmentId;
	private String role;
	@ManyToOne(optional = true)
	@JoinColumn(insertable = false, updatable = false, name="departmentId")
	private Department department;
	@OneToMany
	@JoinColumn(insertable = false, updatable = false, name ="userId")
	private List<Salary> salaryList;
}
