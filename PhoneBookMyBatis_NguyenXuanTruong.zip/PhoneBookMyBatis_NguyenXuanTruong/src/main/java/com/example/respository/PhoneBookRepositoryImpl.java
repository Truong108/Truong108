//package com.example.respository;
//
//import java.util.List;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.jdbc.core.JdbcTemplate;
//import org.springframework.stereotype.Repository;
//
//import com.example.model.PhoneBook;
//import com.example.model.PhoneBookRowMapper;
//@Repository
//public class PhoneBookRepositoryImpl implements PhoneBookRepository {
//	@Autowired
//	private JdbcTemplate jdbcTemplate;
//	@Override
//	public List<PhoneBook> getAllPhoneBook() {
//		String query ="select id, first_name,last_name,phone_number"
//	+ " from phone_book";
//	List<PhoneBook>list=jdbcTemplate.query(query,new PhoneBookRowMapper());
//		return list;
//	}
////	Them
//	public void addPhoneBook(PhoneBook phoneBook) {
//		String query="insert into phone_book(first_name, last_name,phone_number)" + " values (?,?,?)";
//		jdbcTemplate.update(query, new Object[] 
//				{phoneBook.getFirstName(),
//				phoneBook.getLastName(),
//				phoneBook.getPhoneNumber()}
//				
//				);
//	}
////	xoa
//	public void deletePhoneBook(int id) {
//		String sql="delete from phone_book where id=?";
//		jdbcTemplate.update(sql,id);
//		
//	}
//	@Override
//	public void updatePhoneBook(PhoneBook phoneBook) {
//		String sql="update phone_book set first_name=?,last_name=?,phone_number=? "
//				+ "where id=?";
//		jdbcTemplate.update(sql,new Object[] {
//				phoneBook.getFirstName(),
//				phoneBook.getLastName(),
//				phoneBook.getPhoneNumber(),
//				phoneBook.getId()
//		});
//	}
//	@Override
//	public PhoneBook findPhoneBookById(int id) {
//		String sql="select id, first_name, last_name,phone_number" 
//	+ " from phone_book"
//	+ " where id=?";
//		PhoneBook phoneBook=jdbcTemplate.queryForObject(sql,new PhoneBookRowMapper(),id);
//		return phoneBook;
//	}
//
//
//}
