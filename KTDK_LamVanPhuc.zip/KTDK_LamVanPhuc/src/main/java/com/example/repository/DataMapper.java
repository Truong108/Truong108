package com.example.repository;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import com.example.model.Item;
import com.example.model.Shipment;
import com.example.model.ShipmentItem;

@Mapper
public interface DataMapper {
	public int insertOne(@Param("item") Item item);

	public List<ShipmentItem> findMany(@Param("shipmentId") Integer selectId);

	public List<ShipmentItem> findMany();
//	public List<Item> findMany();

//	public List<Customer> getAllCustomer();
//
//	public List<Invoice> getAllInvoice(@Param("customerId") Integer customerId);
//	
//	public void deleteOneInvoice(Integer invoiceNumber);
	public List<Shipment> findManyShipment();

	public void deleteOneItem(Integer id);

}
