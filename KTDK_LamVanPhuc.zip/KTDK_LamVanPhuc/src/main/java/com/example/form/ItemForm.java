package com.example.form;

import java.util.Date;

import org.springframework.format.annotation.DateTimeFormat;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class ItemForm {
	private Integer itemId;
//	@NotBlank(groups = ValidGroup1.class)
	private String description;
	@DateTimeFormat(pattern = "dd/MM/yyyy")
	@NotNull(groups = ValidGroup1.class)
	private Date purchaseDate;
//	@NotBlank(groups = ValidGroup1.class)
	private String store;
//	@NotBlank(groups = ValidGroup1.class)
	private String city;

	private Integer quantity;

	private Double localCurrencyAmount;

	private Double exchangeRate;
}
