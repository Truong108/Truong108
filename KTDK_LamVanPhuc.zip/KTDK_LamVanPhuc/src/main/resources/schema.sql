CREATE TABLE ITEM (
	item_id			int	not null auto_increment,
  	description		varchar(25)	not null, 
	purchase_date	date	not null,
	store			char(50)	not null,
  	city			char(35)	not null,
  	quantity		int	not null,
	local_currency_amount	numeric(18,2)	 not null,
	exchange_rate	numeric(12,6)  not null,	
	primary key (item_id)
);

CREATE TABLE SHIPMENT (
	shipment_id	int	not null auto_increment,
	shipper_name	char(35)	not null,
	shipper_invoice_number	  int	not null,
	departure_date	date	         null,
	arrival_date date    	     null,
  	insured_value numeric(12,2)  not null,
	primary key (shipment_id)
);

CREATE TABLE SHIPMENT_ITEM (
	shipment_id 	int not null,
	shipment_item_id		int	not null,  
	item_id		        int	not null,
	cost	numeric(12,2)	not null,
	primary key(shipment_id, shipment_item_id),
	foreign key(shipment_id) references shipment(shipment_id),						
	foreign key(item_id) references item(item_id)
	on delete cascade
);