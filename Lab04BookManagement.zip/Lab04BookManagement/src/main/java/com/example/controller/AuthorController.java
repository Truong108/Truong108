package com.example.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.example.model.Author;
import com.example.service.AuthorService;

@Controller
@RequestMapping("/author")
public class AuthorController {
	@Autowired
	private AuthorService authorService;

	@GetMapping("/list")
	public String getAuthor(Model model) {
		List<Author> author = authorService.getAllAuthor();
		model.addAttribute("authorList", author);
		return "author/author";
	}

	@GetMapping("/create")
	public String getAuthorAdd() {

		return "author/add";
	}
	
	@GetMapping(value= {"/detail","/detail/","detail/{id}"})
	public String showAuthorDetail(@PathVariable(value = "id", required = false) Integer id, Model model) {
		Author author = authorService.getOneAuthor(id);
		if(author ==null)
			author = new Author();
		model.addAttribute("author", author);
		return "author/author_form";
	}
	
	@PostMapping(value="/detail", params = "save")
	public String createAuthor(@ModelAttribute("author") Author author, Model model) {
		authorService.createAuthor(author);
		model.addAttribute("message", "Create successful!");
		return "author/author_form";
	}
	
	@PostMapping(value="/detail", params = "update")
	public String updateAuthor(@ModelAttribute("author") Author author, Model model) {
		authorService.updateAuthor(author);
		model.addAttribute("message", "Update successful!");
		return "author/author_form";
	}
	
	@GetMapping("/delete/{id}")
	public String deleteAuthor(@PathVariable("id") Integer id) {
		authorService.deleteAuthor(id);
		return "redirect:/author/list";
	}

}
