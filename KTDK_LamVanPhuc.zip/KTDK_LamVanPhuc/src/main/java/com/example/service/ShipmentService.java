package com.example.service;

import java.util.List;

import com.example.model.Shipment;

public interface ShipmentService {

	List<Shipment> getAllShipment();

}
