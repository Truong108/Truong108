insert into author (name, genre,age) values 
	('Andrew Glover','History',34),
	('Lacey, Nichola','Programing language',28),
	('Jessika Sobanski','Math',48),
	('Nha Gia Kim','Math',40);

insert into book (isbn, title, author_id) values
	('0001-JN','A History of Ancient Prague',1),
	('0002-JN','A People History',1),
	('0003-JN','World History',1),
	('9776-LN','Python by Example (Learning to Program in 150 Challenges)',2),
	('9777-LN','Beginning C# 7 Programming with Visual Studio',2),
	('9778-LN','Learn Java in One Day and Learn It Well',2),
	('9779-LN','Head First Java, 2nd Edition ',2),
	('9780-LN','Data Structures and Algorithms Made Easy in Java',2),
	('8781-JS','Visual Math - See How Math Makes Sense',3),
	('8782-JS','The Math Book (Big Ideas Simply Explained)',3),
	('8783-JS','Help Your Kids with Math',3),
	('8784-JS','Fundamentals of Electric Circuits',3),
	('8785-JS','The Math Book, Big Ideas Simply Explained',3),
	('8786-JS','Prime Numbers: The Most Mysterious Figures in Math',3);
