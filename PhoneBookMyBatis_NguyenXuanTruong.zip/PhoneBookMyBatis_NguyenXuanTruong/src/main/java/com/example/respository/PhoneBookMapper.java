package com.example.respository;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import com.example.model.PhoneBook;
@Mapper
public interface PhoneBookMapper {
	public List<PhoneBook> getAllPhoneBook();
	
	public List<PhoneBook> getPhoneBookByCriceria(@Param("search") String lastName);

	void addPhoneBook(PhoneBook phoneBook);

	public void deletePhoneBook(@Param("delete")int id);

	public void updatePhoneBook(@Param("update")PhoneBook phoneBook);

	public PhoneBook findPhoneBookById(int id);
	

}
